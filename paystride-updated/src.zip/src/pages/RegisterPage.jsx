import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import toast from 'react-hot-toast'
import { useAuth } from '../context/AuthContext'
import api from '../services/api'
import styles from './AuthPage.module.css'

const features = [
  { icon: '🚀', title: 'Setup in 5 minutes', desc: 'No complex onboarding' },
  { icon: '💼', title: 'Multi-department support', desc: 'Organize any workforce' },
  { icon: '🔒', title: 'Enterprise-grade security', desc: 'Your data stays safe' },
]

export default function RegisterPage() {
  const [form, setForm] = useState({
    companyName: '', companyCity: '', companyEmail: '',
    adminName: '', adminEmail: '', adminPassword: ''
  })
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  function set(field) {
    return e => setForm(prev => ({ ...prev, [field]: e.target.value }))
  }

  async function handleRegister(e) {
    e.preventDefault()
    if (!form.companyName || !form.adminEmail || !form.adminPassword || !form.adminName) {
      toast.error('Please fill all required fields')
      return
    }
    setLoading(true)
    try {
      const res = await api.post('/auth/register', form)
      const { token, userId, companyId, name, role, companyName } = res.data
      login({ userId, companyId, name, role, companyName }, token)
      toast.success('Company registered! Welcome to PayStride.')
      navigate('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.page}>
      {/* Left branding panel */}
      <div className={styles.leftPanel}>
        <Link to="/" className={styles.logo}>
          <div className={styles.logoIcon}>P</div>
          <span className={styles.logoText}>PayStride</span>
        </Link>
        <h2 className={styles.panelTitle}>
          Start managing<br /><span className={styles.panelGold}>payroll today</span>
        </h2>
        <p className={styles.panelSubtext}>
          Register your company and have your first payroll ready in minutes — not days.
        </p>
        <div className={styles.featureList}>
          {features.map((f, i) => (
            <div key={i} className={styles.featureItem}>
              <div className={styles.featureItemIcon}>{f.icon}</div>
              <div className={styles.featureItemText}>
                <strong>{f.title}</strong>
                <span>{f.desc}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right form panel */}
      <div className={styles.rightPanel}>
        <div className={styles.formBox}>
          <Link to="/" className={styles.homeLink}>← Back to home</Link>
          <h1 className={styles.formTitle}>Create your account</h1>
          <p className={styles.formSubtitle}>Set up your company on PayStride</p>

          <form onSubmit={handleRegister} className={styles.form}>
            <p className="section-title" style={{color:'rgba(255,255,255,0.35)', marginBottom:'10px'}}>Company Details</p>
            <div className={styles.formRow}>
              <div className="input-group">
                <label>Company name *</label>
                <input placeholder="Sharma Constructions" value={form.companyName} onChange={set('companyName')} />
              </div>
              <div className="input-group">
                <label>City</label>
                <input placeholder="Pune" value={form.companyCity} onChange={set('companyCity')} />
              </div>
            </div>
            <div className="input-group">
              <label>Company email</label>
              <input type="email" placeholder="info@company.com" value={form.companyEmail} onChange={set('companyEmail')} />
            </div>

            <p className="section-title" style={{color:'rgba(255,255,255,0.35)', marginBottom:'10px', marginTop:'4px'}}>Admin Account</p>
            <div className={styles.formRow}>
              <div className="input-group">
                <label>Your name *</label>
                <input placeholder="Pratik Raut" value={form.adminName} onChange={set('adminName')} />
              </div>
              <div className="input-group">
                <label>Your email *</label>
                <input type="email" placeholder="you@company.com" value={form.adminEmail} onChange={set('adminEmail')} />
              </div>
            </div>
            <div className="input-group">
              <label>Password *</label>
              <input type="password" placeholder="Min 6 characters" value={form.adminPassword} onChange={set('adminPassword')} />
            </div>

            <button type="submit" className={`btn btn-gold ${styles.submitBtn}`} disabled={loading}>
              {loading ? 'Creating account...' : 'Create Account →'}
            </button>
          </form>

          <p className={styles.switchText}>
            Already have an account?{' '}
            <Link to="/login" className={styles.switchLink}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
