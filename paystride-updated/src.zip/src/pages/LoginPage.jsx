import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import toast from 'react-hot-toast'
import { useAuth } from '../context/AuthContext'
import api from '../services/api'
import styles from './AuthPage.module.css'

const features = [
  { icon: '⚡', title: 'Run payroll in minutes', desc: 'Not hours or days' },
  { icon: '👥', title: 'Manage your full team', desc: 'Workers, hours, salaries' },
  { icon: '📊', title: 'Real-time insights', desc: 'Live wage & cost data' },
]

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  async function handleLogin(e) {
    e.preventDefault()
    if (!email || !password) { toast.error('Please enter email and password'); return }
    setLoading(true)
    try {
      const res = await api.post('/auth/login', { email, password })
      const { token, userId, companyId, name, role, companyName } = res.data
      login({ userId, companyId, name, role, companyName }, token)
      toast.success(`Welcome back, ${name}!`)
      navigate('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Invalid credentials')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.page}>
      {/* Left branding panel */}
      <div className={styles.leftPanel}>
        <Link to="/" className={styles.logo}>
          <div className={styles.logoIcon}>P</div>
          <span className={styles.logoText}>PayStride</span>
        </Link>
        <h2 className={styles.panelTitle}>
          The smarter way<br />to <span className={styles.panelGold}>pay your team</span>
        </h2>
        <p className={styles.panelSubtext}>
          Join 500+ companies managing payroll with confidence on PayStride.
        </p>
        <div className={styles.featureList}>
          {features.map((f, i) => (
            <div key={i} className={styles.featureItem}>
              <div className={styles.featureItemIcon}>{f.icon}</div>
              <div className={styles.featureItemText}>
                <strong>{f.title}</strong>
                <span>{f.desc}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right form panel */}
      <div className={styles.rightPanel}>
        <div className={styles.formBox}>
          <Link to="/" className={styles.homeLink}>← Back to home</Link>
          <h1 className={styles.formTitle}>Welcome back</h1>
          <p className={styles.formSubtitle}>Sign in to your PayStride account</p>

          <form onSubmit={handleLogin} className={styles.form}>
            <div className="input-group">
              <label>Email address</label>
              <input
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                autoComplete="email"
              />
            </div>
            <div className="input-group">
              <label>Password</label>
              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="current-password"
              />
            </div>
            <button
              type="submit"
              className={`btn btn-gold ${styles.submitBtn}`}
              disabled={loading}
            >
              {loading ? 'Signing in...' : 'Sign In →'}
            </button>
          </form>

          <p className={styles.switchText}>
            New to PayStride?{' '}
            <Link to="/register" className={styles.switchLink}>Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
