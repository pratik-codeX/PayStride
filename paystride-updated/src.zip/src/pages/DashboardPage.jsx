import { useState, useEffect } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import api from '../services/api'
import { formatCurrency, formatHours } from '../utils/format'
import styles from './DashboardPage.module.css'

export default function DashboardPage() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    api.get('/dashboard')
      .then(res => setStats(res.data))
      .catch(() => toast.error('Failed to load dashboard'))
      .finally(() => setLoading(false))
  }, [])

  const cards = stats ? [
    {
      label: 'Total Workers',
      value: stats.totalWorkers,
      icon: '👷',
      color: 'blue',
      change: '+3 this month',
      changeUp: true,
    },
    {
      label: 'Hours This Month',
      value: formatHours(stats.totalHoursThisMonth),
      icon: '⏱',
      color: 'gold',
      change: 'Updated today',
      changeUp: true,
    },
    {
      label: 'Wage Liability',
      value: formatCurrency(stats.totalWageLiabilityThisMonth),
      icon: '₹',
      color: 'green',
      change: 'Current month',
      changeUp: null,
    },
  ] : []

  const quickActions = [
    { label: 'Add Worker', desc: 'Register a new employee', path: '/workers', icon: '👤', color: 'blue' },
    { label: 'Log Hours', desc: "Mark today's attendance", path: '/hours', icon: '⏰', color: 'gold' },
    { label: 'Generate Payroll', desc: 'Calculate & process wages', path: '/payroll', icon: '💰', color: 'green' },
  ]

  const now = new Date()
  const greeting = now.getHours() < 12 ? 'Good morning' : now.getHours() < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div className="page-wrapper">
      {/* Header */}
      <div className={styles.header}>
        <div>
          <p className={styles.greeting}>{greeting} 👋</p>
          <h1 className={styles.title}>
            Welcome back, <span className={styles.titleName}>{user?.name?.split(' ')[0]}</span>
          </h1>
          <p className={styles.company}>{user?.companyName}</p>
        </div>
        <div className={styles.headerRight}>
          <div className={styles.monthBadge}>
            <span className={styles.monthDot}></span>
            {stats?.monthYear || now.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </div>
        </div>
      </div>

      {loading ? (
        <div className={styles.loading}>
          <div className={styles.loadingSpinner}></div>
          <span>Loading dashboard...</span>
        </div>
      ) : (
        <>
          {/* Stats Cards */}
          <div className={styles.statsGrid}>
            {cards.map((card, i) => (
              <div
                key={card.label}
                className={`${styles.statCard} ${styles[card.color]}`}
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className={styles.statTop}>
                  <div className={styles.statIconWrap}>
                    <span className={styles.statIcon}>{card.icon}</span>
                  </div>
                  <span className={`${styles.statChange} ${card.changeUp ? styles.statChangeUp : ''}`}>
                    {card.change}
                  </span>
                </div>
                <p className={styles.statValue}>{card.value}</p>
                <p className={styles.statLabel}>{card.label}</p>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className={styles.section}>
            <h2 className={styles.sectionHeading}>Quick Actions</h2>
            <div className={styles.actionsGrid}>
              {quickActions.map((action, i) => (
                <button
                  key={action.path}
                  className={`${styles.actionCard} ${styles[action.color + 'Action']}`}
                  onClick={() => navigate(action.path)}
                  style={{ animationDelay: `${i * 0.07}s` }}
                >
                  <div className={styles.actionIcon}>{action.icon}</div>
                  <div>
                    <p className={styles.actionLabel}>{action.label}</p>
                    <p className={styles.actionDesc}>{action.desc}</p>
                  </div>
                  <span className={styles.actionArrow}>→</span>
                </button>
              ))}
            </div>
          </div>

          {/* Summary Panel */}
          <div className={styles.section}>
            <h2 className={styles.sectionHeading}>Overview</h2>
            <div className={styles.overviewGrid}>
              <div className={styles.overviewCard}>
                <div className={styles.overviewCardHeader}>
                  <span className={styles.overviewCardIcon}>📋</span>
                  <strong>Payroll Summary</strong>
                </div>
                <div className={styles.overviewRows}>
                  <div className={styles.overviewRow}>
                    <span>Total Workers</span>
                    <strong>{stats?.totalWorkers ?? '—'}</strong>
                  </div>
                  <div className={styles.overviewRow}>
                    <span>Hours Logged</span>
                    <strong>{formatHours(stats?.totalHoursThisMonth)}</strong>
                  </div>
                  <div className={styles.overviewRow}>
                    <span>Wage Liability</span>
                    <strong className={styles.overviewHighlight}>{formatCurrency(stats?.totalWageLiabilityThisMonth)}</strong>
                  </div>
                  <div className={styles.overviewRow}>
                    <span>Pay Period</span>
                    <strong>{stats?.monthYear || '—'}</strong>
                  </div>
                </div>
              </div>

              <div className={styles.overviewCard}>
                <div className={styles.overviewCardHeader}>
                  <span className={styles.overviewCardIcon}>⚡</span>
                  <strong>Getting Started</strong>
                </div>
                <div className={styles.checklist}>
                  <div className={styles.checkItem}>
                    <div className={`${styles.checkDot} ${styles.checkDone}`}>✓</div>
                    <span>Company account created</span>
                  </div>
                  <div className={styles.checkItem}>
                    <div className={`${styles.checkDot} ${(stats?.totalWorkers ?? 0) > 0 ? styles.checkDone : ''}`}>
                      {(stats?.totalWorkers ?? 0) > 0 ? '✓' : '1'}
                    </div>
                    <span>Add your first worker</span>
                  </div>
                  <div className={styles.checkItem}>
                    <div className={`${styles.checkDot} ${(stats?.totalHoursThisMonth ?? 0) > 0 ? styles.checkDone : ''}`}>
                      {(stats?.totalHoursThisMonth ?? 0) > 0 ? '✓' : '2'}
                    </div>
                    <span>Log working hours</span>
                  </div>
                  <div className={styles.checkItem}>
                    <div className={styles.checkDot}>3</div>
                    <span>Generate your first payroll</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
