import { useState } from 'react'
import { NavLink, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import styles from './Navbar.module.css'

const NAV_LINKS = [
  { to: '/dashboard', label: 'Dashboard', icon: '⊞' },
  { to: '/workers', label: 'Workers', icon: '👥' },
  { to: '/hours', label: 'Hours', icon: '⏱' },
  { to: '/payroll', label: 'Payroll', icon: '💰' },
]

export default function Navbar() {
  const { user, logout, isAuthenticated } = useAuth()
  const [mobileOpen, setMobileOpen] = useState(false)
  if (!isAuthenticated) return null

  const initials = user?.name
    ? user.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    : 'U'

  return (
    <nav className={styles.nav}>
      <div className={styles.inner}>
        {/* Logo */}
        <Link to="/dashboard" className={styles.logo}>
          <div className={styles.logoIcon}>P</div>
          <span className={styles.logoText}>PayStride</span>
        </Link>

        {/* Nav links */}
        <div className={styles.links}>
          {NAV_LINKS.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            >
              <span className={styles.linkIcon}>{link.icon}</span>
              {link.label}
            </NavLink>
          ))}
        </div>

        {/* Right side */}
        <div className={styles.right}>
          <div className={styles.userInfo}>
            <div className={styles.avatar}>{initials}</div>
            <div className={styles.userText}>
              <span className={styles.userName}>{user?.name?.split(' ')[0]}</span>
              <span className={styles.userRole}>{user?.companyName}</span>
            </div>
          </div>
          <button className={styles.logout} onClick={logout} title="Sign out">
            <span>⎋</span>
          </button>
          <button className={styles.menuBtn} onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? '✕' : '☰'}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className={styles.mobileMenu}>
          {NAV_LINKS.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `${styles.mobileLink} ${isActive ? styles.mobileLinkActive : ''}`}
              onClick={() => setMobileOpen(false)}
            >
              <span>{link.icon}</span> {link.label}
            </NavLink>
          ))}
          <button className={`btn btn-ghost ${styles.mobileLogout}`} onClick={logout}>Sign Out</button>
        </div>
      )}
    </nav>
  )
}
